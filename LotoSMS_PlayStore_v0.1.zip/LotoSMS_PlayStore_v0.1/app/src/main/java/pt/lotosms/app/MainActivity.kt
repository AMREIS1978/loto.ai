package pt.lotosms.app

import android.Manifest
import android.app.role.RoleManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseMessaging.getInstance().subscribeToTopic("official-results")
        setContent { LotoSmsApp() }
    }

    @Composable
    private fun LotoSmsApp() {
        val store = remember { AppStore(this) }
        var tab by remember { mutableIntStateOf(0) }
        var refresh by remember { mutableIntStateOf(0) }
        val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh++ }
        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
        val roleHeld = remember(refresh) { SmsEngine.isDefaultSms(this) }

        MaterialTheme(colorScheme = lightColorScheme()) {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        listOf("Início" to Icons.Default.Home, "Grupos" to Icons.Default.Group, "Enviar" to Icons.Default.Send, "Histórico" to Icons.Default.History, "Definições" to Icons.Default.Settings).forEachIndexed { i, p ->
                            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(p.second, null) }, label = { Text(p.first) })
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> HomeScreen(store, roleHeld,
                            requestRole = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                    val rm = getSystemService(RoleManager::class.java)
                                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
                                }
                            },
                            requestPermissions = { permLauncher.launch(arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)) },
                            onRefresh = { refresh++ })
                        1 -> GroupsScreen(store)
                        2 -> QuickSendScreen(store)
                        3 -> PlaceholderScreen("Histórico", "Os envios automáticos e manuais ficam registados aqui.", Icons.Default.History)
                        else -> SettingsScreen(store, roleHeld)
                    }
                }
            }
        }
    }

    @Composable
    private fun HomeScreen(store: AppStore, roleHeld: Boolean, requestRole: () -> Unit, requestPermissions: () -> Unit, onRefresh: () -> Unit) {
        var automation by remember { mutableStateOf(store.automationEnabled()) }
        val groups = remember { store.groups() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("LotoSMS", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Resultados que chegam às pessoas certas, pelo seu número.", style = MaterialTheme.typography.bodyLarge)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Security, null); Spacer(Modifier.width(8.dp)); Text("Estado da configuração", fontWeight = FontWeight.Bold) }
                    Text(if (roleHeld) "✓ LotoSMS é o gestor SMS predefinido" else "Falta definir LotoSMS como gestor SMS predefinido")
                    if (!roleHeld) Button(onClick = requestRole) { Text("Definir como app SMS") }
                    if (roleHeld) OutlinedButton(onClick = requestPermissions) { Text("Autorizar SMS") }
                }
            }
            Card(shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Envio automático", fontWeight = FontWeight.Bold); Text("Envia quando a API confirma um resultado novo.") }
                        Switch(checked = automation, onCheckedChange = {
                            automation = it; store.setAutomationEnabled(it); if (it) store.setTermsAccepted(true); onRefresh()
                        }, enabled = roleHeld)
                    }
                    if (automation) Text("Ativo • proteção contra duplicados ligada", color = MaterialTheme.colorScheme.primary)
                }
            }
            Text("Grupos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            groups.forEach { g -> Card(shape = RoundedCornerShape(20.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Group, null); Spacer(Modifier.width(12.dp)); Column { Text(g.name, fontWeight = FontWeight.SemiBold); Text("${g.numbers.size} destinatários • ${g.enabledGames.joinToString()}") } } } }
            Text("Nota: os SMS são enviados pelo seu SIM e podem ter custos segundo o tarifário da operadora.", style = MaterialTheme.typography.bodySmall)
        }
    }

    @Composable
    private fun GroupsScreen(store: AppStore) {
        var name by remember { mutableStateOf("") }; var numbers by remember { mutableStateOf("") }; var refresh by remember { mutableIntStateOf(0) }
        val groups = remember(refresh) { store.groups() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Grupos", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Crie listas para Família, Amigos, Clientes ou outras utilizações autorizadas.")
            OutlinedTextField(name, { name = it }, label = { Text("Nome do grupo") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(numbers, { numbers = it }, label = { Text("Números (separados por vírgula)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Button(onClick = { if (name.isNotBlank()) { store.addGroup(name, numbers.split(",", ";", "\n"), setOf("Euromilhões", "Totoloto", "Joker")); name = ""; numbers = ""; refresh++ } }, modifier = Modifier.fillMaxWidth()) { Text("Criar grupo") }
            groups.forEach { g -> Card(shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Text(g.name, fontWeight = FontWeight.Bold); Text("${g.numbers.size} contactos"); Text(g.enabledGames.joinToString(" • ")) } } }
        }
    }

    @Composable
    private fun QuickSendScreen(store: AppStore) {
        var msg by remember { mutableStateOf("") }; var selected by remember { mutableStateOf(setOf<String>()) }; var status by remember { mutableStateOf("") }
        val groups = remember { store.groups() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Enviar agora", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Escolha grupos, confirme a mensagem e envie pelo seu SIM.")
            groups.forEach { g -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Checkbox(g.id in selected, { c -> selected = if (c) selected + g.id else selected - g.id }); Column { Text(g.name, fontWeight = FontWeight.SemiBold); Text("${g.numbers.size} destinatários") } } }
            OutlinedTextField(msg, { msg = it }, label = { Text("Mensagem") }, modifier = Modifier.fillMaxWidth(), minLines = 5)
            val recipients = groups.filter { it.id in selected }.flatMap { it.numbers }.distinct()
            Text("${recipients.size} destinatários únicos")
            Button(onClick = { val (ok, fail) = SmsEngine.send(this, recipients, msg); status = "$ok enviados • $fail falharam" }, enabled = msg.isNotBlank() && recipients.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Enviar agora") }
            if (status.isNotBlank()) AssistChip(onClick = {}, label = { Text(status) })
        }
    }

    @Composable
    private fun SettingsScreen(store: AppStore, roleHeld: Boolean) {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Definições", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            ListItem(headlineContent = { Text("Gestor SMS predefinido") }, supportingContent = { Text(if (roleHeld) "Ativo" else "Não ativo") }, leadingContent = { Icon(Icons.Default.Message, null) })
            ListItem(headlineContent = { Text("Privacidade") }, supportingContent = { Text("Dados de grupos ficam no dispositivo. Sem publicidade baseada em SMS.") }, leadingContent = { Icon(Icons.Default.PrivacyTip, null) })
            ListItem(headlineContent = { Text("Automatismos") }, supportingContent = { Text(if (store.automationEnabled()) "Ligados" else "Desligados") }, leadingContent = { Icon(Icons.Default.AutoAwesome, null) })
        }
    }

    @Composable
    private fun PlaceholderScreen(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(icon, null, modifier = Modifier.size(54.dp)); Spacer(Modifier.height(12.dp)); Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text(body) }
    }
}
