package pt.lotosms.app

data class SmsGroup(val id: String, val name: String, val numbers: List<String>, val enabledGames: Set<String>)
data class DrawResult(val drawId: String, val game: String, val date: String, val numbers: String, val extras: String = "", val jackpot: String = "")
data class SendRecord(val id: String, val drawId: String, val game: String, val at: Long, val recipients: Int, val ok: Int, val failed: Int)
