package pt.lotosms.app

import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class ResultPushService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        // Não enviamos contactos ao backend. O dispositivo subscreve apenas o tópico de resultados.
        FirebaseMessaging.getInstance().subscribeToTopic("official-results")
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val d = message.data
        val drawId = d["drawId"] ?: return
        val game = d["game"] ?: return
        val date = d["date"] ?: ""
        val numbers = d["numbers"] ?: return
        Automation.process(applicationContext, DrawResult(drawId, game, date, numbers, d["extras"] ?: "", d["jackpot"] ?: ""))
    }
}
