package pt.lotosms.app

import android.content.Context
import android.util.Log

object Automation {
    fun process(context: Context, result: DrawResult) {
        val store = AppStore(context)
        if (!store.automationEnabled() || !store.termsAccepted()) return
        if (!SmsEngine.canSend(context)) return
        if (store.hasProcessed(result.drawId)) return

        val recipients = store.groups()
            .filter { result.game in it.enabledGames }
            .flatMap { it.numbers }
            .distinct()
        if (recipients.isEmpty()) return

        val message = buildString {
            append("🍀 ${result.game.uppercase()} — ${result.date}\n")
            append("Chave: ${result.numbers}")
            if (result.extras.isNotBlank()) append("\n${result.extras}")
            if (result.jackpot.isNotBlank()) append("\nJackpot: ${result.jackpot}")
            append("\nBoa sorte!")
        }
        val (ok, fail) = SmsEngine.send(context, recipients, message)
        if (ok > 0 && fail == 0) store.markProcessed(result.drawId)
        Log.i("LotoSMS", "Draw ${result.drawId}: ok=$ok fail=$fail")
    }
}
