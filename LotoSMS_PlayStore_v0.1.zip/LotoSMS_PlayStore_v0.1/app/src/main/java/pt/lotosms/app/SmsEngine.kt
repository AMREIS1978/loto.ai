package pt.lotosms.app

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

object SmsEngine {
    fun isDefaultSms(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = context.getSystemService(RoleManager::class.java)
            return rm?.isRoleHeld(RoleManager.ROLE_SMS) == true
        }
        @Suppress("DEPRECATION")
        return android.provider.Telephony.Sms.getDefaultSmsPackage(context) == context.packageName
    }

    fun canSend(context: Context): Boolean = isDefaultSms(context) &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    fun send(context: Context, recipients: List<String>, message: String): Pair<Int, Int> {
        if (!canSend(context)) return 0 to recipients.size
        val unique = recipients.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        var ok = 0; var failed = 0
        val manager = if (Build.VERSION.SDK_INT >= 31) context.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
        unique.forEach { number ->
            runCatching {
                val parts = manager.divideMessage(message)
                if (parts.size <= 1) manager.sendTextMessage(number, null, message, null, null)
                else manager.sendMultipartTextMessage(number, null, parts, null, null)
            }.onSuccess { ok++ }.onFailure { failed++ }
        }
        return ok to failed
    }
}
