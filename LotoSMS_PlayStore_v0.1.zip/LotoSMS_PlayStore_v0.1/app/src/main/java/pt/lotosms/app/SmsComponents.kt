package pt.lotosms.app

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.provider.Telephony

class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        // Base para inbox da app. Não envia nem partilha o conteúdo recebido.
        // A persistência/visualização de conversas deve ser implementada antes da publicação.
    }
}

class MmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { /* suporte MMS mínimo exigido pelo papel SMS */ }
}

class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
