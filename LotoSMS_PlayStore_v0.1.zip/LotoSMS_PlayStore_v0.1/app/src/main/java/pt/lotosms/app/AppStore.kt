package pt.lotosms.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class AppStore(context: Context) {
    private val p = context.getSharedPreferences("lotosms_secure_prefs", Context.MODE_PRIVATE)

    fun automationEnabled() = p.getBoolean("automation", false)
    fun setAutomationEnabled(v: Boolean) = p.edit().putBoolean("automation", v).apply()
    fun termsAccepted() = p.getBoolean("automation_terms", false)
    fun setTermsAccepted(v: Boolean) = p.edit().putBoolean("automation_terms", v).apply()

    fun groups(): List<SmsGroup> {
        val raw = p.getString("groups", null) ?: return listOf(
            SmsGroup("family", "Família", emptyList(), setOf("Euromilhões", "Totoloto", "Joker"))
        )
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val nums = o.getJSONArray("numbers")
                val games = o.getJSONArray("games")
                SmsGroup(
                    o.getString("id"), o.getString("name"),
                    (0 until nums.length()).map { nums.getString(it) },
                    (0 until games.length()).map { games.getString(it) }.toSet()
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveGroups(groups: List<SmsGroup>) {
        val arr = JSONArray()
        groups.forEach { g ->
            arr.put(JSONObject().apply {
                put("id", g.id); put("name", g.name)
                put("numbers", JSONArray(g.numbers)); put("games", JSONArray(g.enabledGames.toList()))
            })
        }
        p.edit().putString("groups", arr.toString()).apply()
    }

    fun addGroup(name: String, numbers: List<String>, games: Set<String>) {
        val list = groups().toMutableList()
        list += SmsGroup(UUID.randomUUID().toString(), name, numbers.map(::normalize).filter { it.isNotBlank() }.distinct(), games)
        saveGroups(list)
    }

    fun hasProcessed(drawId: String) = p.getStringSet("processed_draws", emptySet())!!.contains(drawId)
    fun markProcessed(drawId: String) {
        val set = p.getStringSet("processed_draws", emptySet())!!.toMutableSet(); set += drawId
        p.edit().putStringSet("processed_draws", set.takeLast(100).toSet()).apply()
    }

    private fun normalize(s: String): String = s.filter { it.isDigit() || it == '+' }.trim()
}
