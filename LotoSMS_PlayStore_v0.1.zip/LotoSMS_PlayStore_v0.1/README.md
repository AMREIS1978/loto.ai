# LotoSMS v0.1 — Android

Primeira base de uma app Android moderna para grupos de SMS, envio imediato e envio automático de resultados pelo SIM/número do utilizador.

## O que já está implementado no código
- UI Jetpack Compose: Início, Grupos, Enviar, Histórico, Definições.
- pedido de papel de gestor SMS (`ROLE_SMS`).
- permissões SMS pedidas apenas depois do papel.
- envio imediato a grupos, com eliminação de números duplicados.
- motor de envio multipart SMS pelo SIM.
- receção de push FCM com novo resultado.
- automatismo com `drawId` idempotente para não repetir o mesmo sorteio.
- armazenamento local simples de grupos/preferências.
- manifesto com componentes necessários como base para a função de gestor SMS.
- rascunho de privacidade e checklist Play Store.

## Ainda obrigatório antes de publicar
- implementar inbox/conversas SMS/MMS completo e persistência no Telephony Provider.
- configurar Firebase (`google-services.json`) e backend de resultados.
- ligar a fonte oficial/autorizada de resultados.
- criar ícone, screenshots, listing e URL final de privacidade.
- testes reais em vários Android/SIM e auditoria de políticas Play.

## Compilar
Abrir a pasta no Android Studio atual, adicionar `app/google-services.json`, sincronizar Gradle e gerar um Android App Bundle (AAB) assinado.

> Este ambiente de criação não inclui Android SDK/Gradle, portanto o ZIP contém o projeto-fonte pronto para abrir no Android Studio, não um APK compilado.
