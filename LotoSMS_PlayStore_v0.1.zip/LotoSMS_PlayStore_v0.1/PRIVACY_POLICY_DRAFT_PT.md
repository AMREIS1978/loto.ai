# Política de Privacidade — rascunho

A LotoSMS é uma aplicação de mensagens SMS. Os grupos, números introduzidos pelo utilizador, preferências de jogos e histórico operacional são tratados localmente no dispositivo, salvo indicação explícita em contrário numa versão futura.

A aplicação pode solicitar acesso a SMS exclusivamente quando estiver definida pelo utilizador como gestor SMS predefinido, para fornecer as funções essenciais de envio, receção e gestão de mensagens. O conteúdo de SMS não é usado para publicidade, perfil comercial ou venda de dados.

A API de resultados envia para o dispositivo apenas dados do sorteio e identificadores técnicos necessários à entrega de notificações. A agenda de destinatários não precisa de ser enviada para o servidor para o envio pelo SIM do utilizador.

O utilizador pode desligar o envio automático a qualquer momento. A aplicação deve disponibilizar meios para apagar os dados locais e, caso venha a existir uma conta remota, apagar a conta e os respetivos dados.

Os SMS enviados pelo SIM podem estar sujeitos ao tarifário da operadora móvel.

[Antes da publicação: inserir identidade do responsável, contacto, URL, bases legais aplicáveis, retenção, subcontratantes, transferências e procedimento de exercício de direitos.]
