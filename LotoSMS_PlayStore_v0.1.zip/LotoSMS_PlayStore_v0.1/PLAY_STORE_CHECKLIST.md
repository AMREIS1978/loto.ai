# Checklist Play Store — LotoSMS

1. O propósito principal publicado deve ser claramente **gestão de SMS/mensagens**, não apenas resultados de lotarias.
2. Solicitar `ROLE_SMS` ao utilizador antes das permissões SMS.
3. Só usar SEND/READ/RECEIVE_SMS enquanto a app for o gestor SMS predefinido.
4. Completar uma experiência real de inbox/conversas e receção de SMS/MMS antes da submissão pública.
5. Preencher a declaração de permissões SMS no Play Console.
6. Política de privacidade pública e dentro da app.
7. Formulário Data safety coerente com o código e SDKs usados.
8. Sem publicidade baseada no conteúdo de SMS/contactos.
9. Consentimento claro para automatismos e para cada grupo; disponibilizar desligar a qualquer momento.
10. Evitar READ_CONTACTS: usar inserção manual/Contact Picker sempre que possível.
11. Explicar que podem existir custos da operadora e impedir duplicados.
12. Testar Dual SIM, sem SIM, roaming, modo avião, permissões revogadas, perda do papel SMS e reinício.
13. Rever políticas imediatamente antes de publicar, porque podem mudar.
