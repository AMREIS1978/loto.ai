import express from 'express';
import helmet from 'helmet';
import admin from 'firebase-admin';

// Produção: GOOGLE_APPLICATION_CREDENTIALS aponta para credenciais do servidor.
admin.initializeApp({ credential: admin.credential.applicationDefault() });
const app = express();
app.use(helmet());
app.use(express.json({ limit: '32kb' }));

const processed = new Set(); // Produção: substituir por BD persistente com UNIQUE(drawId).

app.get('/health', (_, res) => res.json({ ok: true, service: 'lotosms-results' }));

app.post('/v1/results', async (req, res) => {
  const auth = req.get('authorization');
  if (!process.env.INGEST_TOKEN || auth !== `Bearer ${process.env.INGEST_TOKEN}`) return res.status(401).json({ error: 'unauthorized' });

  const { drawId, game, date, numbers, extras = '', jackpot = '', verified = false } = req.body ?? {};
  if (!drawId || !game || !date || !numbers || verified !== true) return res.status(400).json({ error: 'invalid_or_unverified_result' });
  if (processed.has(drawId)) return res.status(200).json({ ok: true, duplicate: true });

  const data = Object.fromEntries(Object.entries({ drawId, game, date, numbers, extras, jackpot }).map(([k,v]) => [k, String(v)]));
  await admin.messaging().send({ topic: 'official-results', data, android: { priority: 'high' } });
  processed.add(drawId);
  res.status(202).json({ ok: true, drawId });
});

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`LotoSMS API on :${port}`));
