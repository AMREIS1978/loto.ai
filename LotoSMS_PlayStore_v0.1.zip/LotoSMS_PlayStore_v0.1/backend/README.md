# Backend/API — contrato de push

A API deve obter resultados de uma fonte autorizada/oficial e só emitir push depois de validar um novo sorteio.

Payload FCM data esperado pela app:

```json
{
  "drawId": "euromilhoes-2026-10-20-086",
  "game": "Euromilhões",
  "date": "20/10/2026",
  "numbers": "07 15 16 22 35",
  "extras": "Estrelas: 04 06",
  "jackpot": "73.000.000 €"
}
```

Regras obrigatórias do servidor:
- `drawId` único e idempotente.
- validar a chave em pelo menos uma fonte oficial/autorizada antes do push.
- HTTPS apenas.
- autenticação do dispositivo e rotação de tokens FCM.
- não armazenar a agenda de contactos no backend; o push contém apenas o resultado.
- rate limit e auditoria.
- nunca incluir API secrets no APK.

## Exemplo de serviço incluído
`server.js` expõe `POST /v1/results`, exige `Authorization: Bearer <INGEST_TOKEN>`, rejeita resultados sem `verified: true` e publica um push FCM de dados no tópico `official-results`.

Na produção, substituir o `Set` em memória por PostgreSQL/SQLite/Redis com unicidade persistente de `drawId` e implementar o coletor/validador da fonte autorizada.
